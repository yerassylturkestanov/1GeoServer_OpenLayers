declare namespace _default {
    let LEFT: string;
    let UP: string;
    let RIGHT: string;
    let DOWN: string;
}
export default _default;
//# sourceMappingURL=Key.d.ts.map