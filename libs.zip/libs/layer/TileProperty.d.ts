declare namespace _default {
    let PRELOAD: string;
    let USE_INTERIM_TILES_ON_ERROR: string;
}
export default _default;
//# sourceMappingURL=TileProperty.d.ts.map