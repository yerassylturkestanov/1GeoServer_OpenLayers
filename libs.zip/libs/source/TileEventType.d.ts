declare namespace _default {
    let TILELOADSTART: string;
    let TILELOADEND: string;
    let TILELOADERROR: string;
}
export default _default;
export type TileSourceEventTypes = 'tileloadstart' | 'tileloadend' | 'tileloaderror';
//# sourceMappingURL=TileEventType.d.ts.map